.$(ajax({
    type: type of call,
    url: the address of the service to be call,
    data: any data to be transferred during a call, ‘ ‘ if no data transfered
    cache: false.
    success: function(datareceived){
    //instructions to execute when the ajax call is succeeds
    },
    error: function(){
    //instructions to execute when the ajax call is failed
    }
    });